function Unauthorized()
{
    return <h1>You have entered wrong Url. No Access</h1>
}

export default Unauthorized;
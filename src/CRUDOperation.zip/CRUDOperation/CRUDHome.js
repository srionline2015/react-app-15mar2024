import React from "react";

export default function Crud_Home()
{
    return <h1>This is Home Page inside CRUD Operation</h1>
}

